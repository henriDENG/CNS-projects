## Java Socket Programming ---- Instant Messenger

Deng ruofan 516261910008

There are totally 7 .java files in the project.  All the files have been already compiled.

The server and the client are compiled into jars respectively.

We can test our project in two ways : 

( in jar )
1. Create a server thread using the command : java -jar Server.jar
2. Create the first client thread using the command : java -jar Client.jar
3. Create the second client thread using the command : java -jar Client.jar
4. Then test the program using the commands written in the assignment file

Another way to run the program is using the following commands:

( in src )
1. javac ServerProgram.java
2. javac ClientProgram.java
1. java ServerProgram
2. java ClientProgram
3. java ClientProgram
4. Test the program

The details are shown in the report.